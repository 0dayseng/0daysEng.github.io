nginx mp4 module DoS & Infoleak Vulnerability (2018)

This proof-of-concept exploit demonstrates an out of bounds read in nginx v1.15.5 heap. This can be worked up to an information disclosure exploit with a bit of extra work. The bug itself, and potentially the exploit, may affect earlier nginx versions.

The bug was reverse-engineered by me from nginx security patches [1], and exploit made public in this release for the first time.

CVE ID: CVE-2018-16845
Exploit developer: Alisa Esage (Zero Day Engineering)
Bug finder: Unknown
Technical details: *to be done*


	Prerequisites

* nginx v1.15.5
* built with the option "--with-http_mp4_module" (non default)


	Impact

Possible attack scenarios for this bug range from a denial of service (DoS) of the nginx worker process, to leaking some bytes (infoleak) from the nginx worker process heap, depending on the implementation of the exploit. 

In case of a DoS attack scenario, the attacker would trigger the bug to crash the nginx worker process. The worker process will be promptly respawned by the parent nginx process after the crash. By repeating the exploit in a loop, the DoS attack can be made persistent in effect, and/or cause a server-global resource exaustion.

In case of an Infoleak attack scenario, the attacker would trigger the bug to read some bytes from the nginx worker process heap. This primitive can be leveraged in an RCE exploit chain to break ASLR, or in a stand-alone setting to disclose potentially sensitive data from the nginx worker process, such as some passwords or the backend configuration. 

In terms of the volume of affected distributions, the impact is not clear. One indicator that the impact may be substantial is that this bug is published in the official nginx security advisory, something that nginx team is extremely reluctant to do (full list of nginx security issues in the global CVE database is at least four times longer than the official list published on the product website). [2]

A realistic attack scenario would use a second bug either in nginx or in other remotely accessible server software for an arbitrary file write on the server.


	How to test

Trigger the bug remotely:
curl http://servername/video/test.mp4?start=2

Test environment configuration is left as an exercise for the reader.


	Notes

Take a look at the crashing stack trace. ngx_writev is the wrapper API in nginx that writes to client connection socket. It means that, while this is a minimalist crash-PoC, the possibility of an infoleak attack is strongly proven.

The impact of the infoleak attack is somewhat limited (hopefully), because nginx spawns one worker process per each connection. So, it should not be possible to read other clients' data, at least in default configuration. 

Tip on configuration: see the included nginx.conf file /video/ section.


	References

[nginx-announce] nginx security advisory (CVE-2018-16845) https://mailman.nginx.org/pipermail/nginx-announce/2018/000221.html?_ga=2.85094233.1343789537.1647791803-1269222961.1647791803
nginx security advisories http://nginx.org/en/security_advisories.html
Zero Day Engineering research http://zerodayengineering.com/research/


	Contacts

Twitter: @alisaesage @zerodaytraining
Email: contact@zerodayengineering.com 
